"use strict";

import * as path from 'path';
//import * as mongoose from 'mongoose';

let dbConfigFilePath = path.resolve(`${process.env.NODE_CONFIG_DIR}/db.json`);
let DbConstants = require(dbConfigFilePath) || {};

export class DBConfig {

  /**
   * Get the DB URL depending on the selected environment or an empty string if not found
   * @param env
   */
  static getUrl(env: string): string {
    if ((DbConstants[env]) && (DbConstants[env].url)) // Safety
    {
      return DbConstants[env].url; // Return the url for the selected environment
    }
    else // Not found?
    {
      return ''; // Return an empty string
    }
  }
}
